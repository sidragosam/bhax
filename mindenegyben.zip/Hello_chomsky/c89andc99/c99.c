#include <stdio.h>

int main() 
{
   for (int i = 10; i < 20; i++) {
       printf("i: %d\n", i);
   }   

   return 0;
}
