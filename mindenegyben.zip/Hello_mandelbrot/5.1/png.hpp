/*
    2  * Copyright (C) 2007,2008   Alex Shulgin
    3  *
    4  * This file is part of png++ the C++ wrapper for libpng.  PNG++ is free
    5  * software; the exact copying conditions are as follows:
    6  *
    7  * Redistribution and use in source and binary forms, with or without
    8  * modification, are permitted provided that the following conditions are met:
    9  *
   10  * 1. Redistributions of source code must retain the above copyright notice,
   11  * this list of conditions and the following disclaimer.
   12  *
   13  * 2. Redistributions in binary form must reproduce the above copyright
   14  * notice, this list of conditions and the following disclaimer in the
   15  * documentation and/or other materials provided with the distribution.
   16  *
   17  * 3. The name of the author may not be used to endorse or promote products
   18  * derived from this software without specific prior written permission.
   19  *
   20  * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
   21  * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
   22  * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
   23  * NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
   24  * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
   25  * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   26  * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   27  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   28  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   29  * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
   30  */
   31 #ifndef PNGPP_PNG_HPP_INCLUDED
   32 #define PNGPP_PNG_HPP_INCLUDED
   33 
   34 #include <png.h>
   35 
   36 #include "config.hpp"
   37 #include "types.hpp"
   38 #include "error.hpp"
   39 #include "color.hpp"
   40 #include "palette.hpp"
   41 #include "tRNS.hpp"
   42 #include "packed_pixel.hpp"
   43 #include "rgb_pixel.hpp"
   44 #include "rgba_pixel.hpp"
   45 #include "gray_pixel.hpp"
   46 #include "ga_pixel.hpp"
   47 #include "index_pixel.hpp"
   48 #include "info_base.hpp"
   49 #include "info.hpp"
   50 #include "end_info.hpp"
   51 #include "io_base.hpp"
   52 #include "reader.hpp"
   53 #include "writer.hpp"
   54 #include "generator.hpp"
   55 #include "consumer.hpp"
   56 #include "pixel_buffer.hpp"
   57 #include "solid_pixel_buffer.hpp"
   58 #include "require_color_space.hpp"
   59 #include "convert_color_space.hpp"
   60 #include "image.hpp"
   61 
  296 #endif // PNGPP_PNG_HPP_INCLUDED
