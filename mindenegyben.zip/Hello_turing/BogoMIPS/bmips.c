#include <time.h>
#include <stdio.h>

	void
	delay (unsigned long long loops)
	{
	  for (unsigned long long i = 0; i < loops; i++);
	}
	
	int
	main (void)
	{
 	 unsigned long long loops_per_sec = 1;
 	 unsigned long long ticks;
	
 	 while ((loops_per_sec <<= 1))	//loopok száma (2 hatványok)
 	   {
      		ticks = clock ();  	  //loop kezdete előtti idő
      		delay (loops_per_sec); 	  //loop meghívása
      		ticks = clock () - ticks; //loop futási ideje
	
     	 	if (ticks <=1)		  //ha a loop futási ideje 1 tick
			{
			printf("Gépi szó hossza: %llu \n",loops_per_sec); 	
				//1 tick alatt mekkora adatmennyiséget 
				//képes feldolgozni (gépi szó)

			return 0;
			}
   	   }
	
  	printf ("failed\n");
  	return -1;
	}

