#include <stdio.h>
#include <stdlib.h>
#include <curses.h>
#include <unistd.h>

int main ()
{
    int xj = 0, xk = 0, yj = 0, yk = 0;
    //int mx = 80 * 2, my = 24 * 3;

    WINDOW *ablak;
    ablak = initscr ();
    noecho ();
    cbreak ();
    nodelay (ablak, true);
	int mx;
	int my;

    for (;;)
    {
	getmaxyx ( ablak, my , mx );
        xj = (xj - 1) % mx;
        xk = (xk + 1) % mx;

        yj = (yj - 1) % my;
        yk = (yk + 1) % my;

        clear ();
        mvprintw (abs ((yj + (my - yk)) / 2),
                  abs ((xj + (mx - xk)) / 2), "O");

        refresh ();
        usleep (150000);

    }
    return 0;
}
