#include <stdio.h>
#include <math.h>

void kiir(double tomb[], int db)
{
	int i;
	for(i=0;i<db;i++)
	printf("Pagerank [%d]:\n %.2f\n",i, tomb[i]);
}

double tavolsag(double pagerank[], double pagerank_temp[], int db)
{
	int i;
	double sum = 0;
	for(i=0;i<db;i++)
	sum+=(pagerank_temp[i] -pagerank[i]) * (pagerank_temp[i] - pagerank[i]);
	return sqrt(sum);
}

int main()
{
	double L[4][4] =
	{
		{0.0, 0.0, 1.0 / 3.0, 0.0},
		{1.0, 1.0 / 2.0, 1.0 / 3.0, 1.0},
		{0.0, 1.0 / 2.0, 0.0 , 0.0},
		{0.0, 0.0, 1.0 / 3.0 , 0.0},
	};
	
	double PR[4] = {0.0, 0.0, 0.0, 0.0};
	double PRv[4] = {1.0 / 4.0, 1.0 / 4.0, 1.0 / 4.0, 1.0 / 4.0};

	long int i,j,h;
	i = 0;
	j = 0;
	h = 5;

	for(;;)
	{
		for(i=0;i<4;i++)
			PR[i] = PRv[i];
		for(i=0;i<4;i++)
		{		
			double t = 0;
			for(j=0;j<4;j++)
			t+=L[i][j]*PR[j];
			PRv[i]=t;
		}
		if(tavolsag(PR,PRv,4) < 0.00001)
		break;
	}
	kiir(PR,4);
	return 0;
}
