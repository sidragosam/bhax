#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

typedef struct node node;
	struct node{
	char name;
	int id;
	node *in[3];
	node *out[3];

};

node* new_node(char n,int i){
	node* new = malloc(sizeof(node));
	new->name = n;
	new->id = i;
	for(int i=0; i<3;i++)
	{
		new->in[i]=NULL;
		new->out[i]=NULL;
	}
	return new;
	}
int main()
{
double pr[4];
double pr2[4];
int temp_id;
char temp_name;
node* nodes[4];
int temp_in[4];
int temp_out[4];
for(int i=0;i<4;i++){
temp_in[i]=0;
temp_out[i]=0;
}

node* node_0 = new_node('A',0);
node* node_1 = new_node('B',1);
node* node_2 = new_node('C',2);
node* node_3 = new_node('D',3);
nodes[0] = node_0;
nodes[1] = node_1;
nodes[2] = node_2;
nodes[3] = node_3;
for(int k=0;k<4;k++){
	printf("%c oldalra mutató oldalak:", nodes[k]->name);
	for(int i=0;i<4;i++){
		scanf("%c",&temp_name);
		for(int j=0;j<4;j++){
			if(nodes[j]->name==temp_name){
				nodes[j]->out[temp_out[j]]=nodes[k];
				nodes[k]->in[temp_in[k]]=nodes[j];
				temp_out[j]++;
				temp_in[k]++;
			}
		}
		
	}
}

for(int i=0;i<4;i++){
temp_in[i]=0;
temp_out[i]=0;
}

for(int j=0;j<4;j++){
for(int i=0;i<3;i++){
if(nodes[j]->in[i]!=NULL){
temp_in[j]++;
}

if(nodes[j]->out[i]!=NULL){
temp_out[j]++;
}
}
}

for(int i=0;i<4;i++){
pr[i]=0.25;
pr2[i]=0;
}

for(int f=0;f<100;f++){

for(int i=0;i<4;i++){
for(int k=0;k<3;k++){
if(nodes[i]->in[k]!=NULL){
pr2[i] += pr[nodes[i]->in[k]->id] / (double)temp_out[nodes[i]->in[k]->id];
}
}
}

for(int h=0;h<4;h++){
pr[h]=pr2[h];
pr2[h]=0;
}
}
for(int i=0;i<4;i++)
{
printf("%f ",pr[i]);
}
printf("\n");
}

