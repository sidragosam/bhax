#include "std_lib_facilities.h"
#include <iostream>
#include <string>

string fullCode;
int tbs;
int subfak;


struct binfa 
{
    char kulcs;
    binfa* bal;
    binfa* jobb;
    binfa* szulo;
};

binfa* createfa(char value, binfa* fszulo) 
{
    binfa* fa = new binfa;
	fa->szulo = fszulo;
    fa->kulcs = value;
    fa->bal = NULL;
    fa->jobb = NULL;
    return fa;
}

int insertfa(binfa*& gyoker, int num) 
{
    if(fullCode[num] == '0'){
        if(gyoker->bal == NULL){
            gyoker->bal = createfa('0', gyoker);
            num = num+1;
        }else{
            num = insertfa(gyoker->bal, num+1);
        }
    }else if(fullCode[num] == '1')
	{
        if(gyoker->jobb == NULL){
            gyoker->jobb = createfa('1', gyoker);
            num = num+1;
        }else{
            num = insertfa(gyoker->jobb, num+1);
        }
    }
    return num;
}

int faLength(binfa* gyoker) 
{
    if(gyoker == NULL) 
	{
        return 0;
    }else{
        return 1+faLength(gyoker->bal)+faLength(gyoker->jobb);
    }
}

int faHeight(binfa* gyoker) 
{
    if(gyoker == NULL) 
	{
        return 0;
    }else{
        return 1+max(faHeight(gyoker->bal), faHeight(gyoker->jobb));
    }
}

int faAgak(binfa* gyoker) 
{
    if(gyoker == NULL) 
	{
        return 0;
    }else if(gyoker->bal == NULL && gyoker->jobb == NULL) 
	{
        return 1;
    }else{
        return faAgak(gyoker->bal)+faAgak(gyoker->jobb);
    }
}

int faAgakSum(binfa* gyoker, int count) 
{
    if(gyoker == NULL) 
	{
        return count;
    }else{
        if(gyoker->bal != NULL && gyoker->jobb != NULL) 
		{
            return faAgakSum(gyoker->bal, count+1)+faAgakSum(gyoker->jobb, count+1);
        }else if(gyoker->bal != NULL) 
		{
            return faAgakSum(gyoker->bal, count+1);
        }else if(gyoker->jobb != NULL) 
		{
            return faAgakSum(gyoker->jobb, count+1);
        }
    }
    return count;
}

int faAgakListazas(binfa* gyoker, int count) 
{
    if(gyoker == NULL) 
	{
        return count;
    }else{
        if(gyoker->bal != NULL && gyoker->jobb != NULL) 
		{
            return faAgakListazas(gyoker->bal, count+1)+faAgakListazas(gyoker->jobb, count+1);
        }else if(gyoker->bal != NULL) 
		{
            return faAgakListazas(gyoker->bal, count+1);
        }else if(gyoker->jobb != NULL) 
		{
            return faAgakListazas(gyoker->jobb, count+1);
        }
    }
    string tmp = "";
    binfa* current = gyoker;
    while(current != NULL) 
	{
        tmp += (current->kulcs);
        current = current->szulo;
    }
	int i;
    for(i=0; i<tmp.length(); i++) 
	{
        if(tmp[tmp.length()-i-1] != '#') 
		{
            cout << tmp[tmp.length()-i-1];
        }
    }
    cout << "(" << i-1 << ")" << "\n";
    return count;
}

double faAgakSzoras(binfa* gyoker, double count, binfa* base) 
{
    if(gyoker == NULL) 
	{
        return count;
    }else{
        if(gyoker->bal != NULL && gyoker->jobb != NULL) 
		{
            return faAgakSzoras(gyoker->bal, count+1, base)+faAgakSzoras(gyoker->jobb, count+1, base);
        }else if(gyoker->bal != NULL) 
		{
            return faAgakSzoras(gyoker->bal, count+1, base);
        }else if(gyoker->jobb != NULL) 
		{
            return faAgakSzoras(gyoker->jobb, count+1, base);
        }
    }
    
    double avg = tbs;
    avg /= subfak;
    return pow(count-avg, 2);
}

int faSum(binfa* gyoker) 
{
    if(gyoker == NULL) 
	{
        return 0;
    }else{
        char tmp;
        if(gyoker->kulcs == '#') { tmp = '0'; }
       else{ tmp = gyoker->kulcs; }
        int n = tmp - '0';
        return n+faSum(gyoker->bal)+faSum(gyoker->jobb);
    }
}

int main() 
{
    string input;
    getline(cin, input);
    string code(input);
	int tordeles = 60;
    if(code.length() <= 1000)
	{
        cout << "Input adatok(Tördelés " << tordeles << " elemenként):\n";
        for(int i = 0; i < code.length(); i++)
		{
            cout << input[i];
            if(((i+1)%tordeles == 0 && i != 0) || i == code.length()-1) 
			{
                cout << "\n";
            }
        }
    }

    binfa* gyoker = createfa('#', NULL);
    int num = 0;
    fullCode = code;
    while(code.length() > num)
	{
        num = insertfa(gyoker, num);
    }
	cout.precision(9);
	double avg = faSum(gyoker);
	double faavg = faAgakSum(gyoker, 0);
	subfak = faAgak(gyoker);
	avg /= (faLength(gyoker)-1);
	tbs = faavg;
	faavg /= subfak;
	double sz = faAgakSzoras(gyoker, 0, gyoker);
    double sz2 = faAgakSzoras(gyoker, 0, gyoker);
    sz /= subfak;
    sz2 /= subfak-1;
    sz = pow(sz, 0.5);
    sz2 = pow(sz2, 0.5);
	int l, h;
    l = faLength(gyoker);
	h = faHeight(gyoker);
	cout << "\nA fa ágainak száma: " << subfak << "\n";
	cout << "A fa ágainak átlagos hossza: " << faavg << "\n";
	cout << "Az ágak hosszainak szórása: " << sz << "\n";
    cout << "Az ágak hosszainak korrigált szórása: " << sz2 << "\n";
    cout << "A fa elemszáma: " << l-1 << " (" << l << ")\n";
    cout << "A fa magassága: " << h-1 << " (" << h << ")\n";
    cout << "A fa elemeinek átlaga: " << avg << "\n";
    if(subfak<=50) 
	{
        cout << "\nA fa ágia:\n";
        faAgakListazas(gyoker, 0);
    }
}
